#!/usr/bin/env python3
def sampleFunction(a=0):
    if a:
        print('running')
    else:
        print('error')

sampleFunction(1)
